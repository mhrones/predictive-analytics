Matthew hrones

My data set is the top scoring submissions of all time from the subreddit "r/news"
The categories are the title of submission, the score of the submission (net upvotes vs downvotes), 
the URL of the submission, and the time the submission was made in UTC
